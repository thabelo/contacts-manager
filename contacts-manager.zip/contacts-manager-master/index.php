<?php
		// Lets go home
		header("Location: application/Views/Users");

