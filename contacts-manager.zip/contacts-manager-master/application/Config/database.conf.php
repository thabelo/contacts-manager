<?php

/**
* Modify this file to match your database details
*/


class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',				// HOST MACHINE 
		'user' => 'root',							// HOST USERNAME 
		'password' => 'online1',			// HOST PASSWORD
		'database' => 'contacts',			// HOST DATABASE (*Optional to change)
	);
}

