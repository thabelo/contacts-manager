
<head>
	<meta charset="utf-8">
	<title>AGSWORLD</title>
	<meta name="description" content="AGSWORLD">
	<meta name="author" content="Thabel Mmbengeni">
	<link rel="stylesheet" href="../../../assets/css/style.css">
	<script language="javascript" src="../../../assets/js/libs/jquery-1.7.1.min.js"></script>
	<script language="javascript" src="../../../assets/js/main.js"></script>
	
</head>

<div class="header-banner"> </div>
<div class="main-header">
	<nav>
		<ul>
			<li> <a href="../Users/"> Home </a> </li>
			<li> <a href="../Users/"> Users</a> </li>
			<li> <a href="../Contacts/"> Contacts </a> </li>
			<li> <a href="../Admin/"> Admin </a> </li>
		</ul>
	</nav>
</div>

